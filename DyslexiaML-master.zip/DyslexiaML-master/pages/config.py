  	# try:
    #   conn = MySQLdb.connect("localhost","ryan","mark50","dyslexia" )
    #   c = conn.cursor()
  	# except:
    #   st.error('Cant establish connecetion, Database Server Down!')
