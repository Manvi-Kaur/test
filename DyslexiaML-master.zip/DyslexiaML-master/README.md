# DyslexiaML
Using Machine Learning to detect Dyslexia.
